import pygame
import random
import asyncio

background_color = (40, 44, 52)
outline_delta = 10
outline_colour = (40 + outline_delta, 44 + outline_delta, 52 + outline_delta)

class Material:
    def __init__(self):
        self.color = (0, 0, 0)

class Cell:
    air = Material()
    air.color = background_color
    sand = Material()
    sand.color = (200, 200, 100)
    water = Material()
    water.color = (10, 10, 255)
    wall = Material()
    wall.color = (0, 0, 0)

    def __init__(self, x, y, mat):
        self.xpos = x
        self.ypos = y
        self.material = mat

pygame.init()

WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600

cell_width = 15
cell_height = 15

num_cells_horizontal = WINDOW_WIDTH // cell_width
num_cells_vertical = WINDOW_HEIGHT // cell_height

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Pixel Game")

def render(cells_grid):
    screen.fill(background_color)
    for row in cells_grid:
        for cell in row:
            cell_rect = pygame.Rect(cell.xpos, cell.ypos, cell_width, cell_height)
            pygame.draw.rect(screen, cell.material.color, cell_rect)
            pygame.draw.rect(screen, outline_colour, cell_rect, 1)

    pygame.display.flip()

def get_cell_at_mouse(mouse_pos, cell_width, cell_height, num_cells_horizontal, num_cells_vertical):
    mouse_x, mouse_y = mouse_pos
    col = mouse_x // cell_width
    row = mouse_y // cell_height
    if 0 <= col < num_cells_horizontal and 0 <= row < num_cells_vertical:
        return row, col
    return None

def physics(old_grid):
    new_grid = [[Cell(cell.xpos, cell.ypos, cell.material) for cell in row] for row in old_grid]

    for ri in range(0, num_cells_vertical - 1):
        for ci in range(0, num_cells_horizontal):
            if (old_grid[ri][ci]).material == Cell.sand:
                if (old_grid[ri + 1][ci]).material == Cell.air:
                    (new_grid[ri + 1][ci]).material = Cell.sand
                    (new_grid[ri][ci]).material = Cell.air
                elif (old_grid[ri + 1][ci]).material == Cell.water:
                    (new_grid[ri][ci]).material = Cell.water
                    (new_grid[ri + 1][ci]).material = Cell.sand
                else:
                    resolved = False
                    order = [[1, -1], [-1, 1]][random.randint(0, 1)]
                    for i in range(0, 2):
                        if (old_grid[ri + 1][ci + order[i]]).material == Cell.air and not resolved:
                            (new_grid[ri + 1][ci + order[i]]).material = Cell.sand
                            (new_grid[ri][ci]).material = Cell.air
                            resolved = True
                    for i in range(0, 2):
                        if (old_grid[ri + 1][ci + order[i]]).material == Cell.water and not resolved:
                            (new_grid[ri + 1][ci + order[i]]).material = Cell.sand
                            (new_grid[ri][ci]).material = Cell.water
                            resolved = True

            if (old_grid[ri][ci]).material == Cell.water:
                if (old_grid[ri + 1][ci]).material == Cell.air:
                    (new_grid[ri + 1][ci]).material = Cell.water
                    (new_grid[ri][ci]).material = Cell.air
                else:
                    resolved = False
                    order = [[1, -1], [-1, 1]][random.randint(0, 1)]
                    for i in range(0, 2):
                        if (old_grid[ri + 1][ci + order[i]]).material == Cell.air and not resolved:
                            (new_grid[ri + 1][ci + order[i]]).material = Cell.water
                            (new_grid[ri][ci]).material = Cell.air
                            resolved = True
                    if not resolved:
                        for i in range(0, 2):
                            if (old_grid[ri][ci + order[i]]).material == Cell.air and (new_grid[ri][ci + order[i]]).material == Cell.air and not resolved:
                                (new_grid[ri][ci + order[i]]).material = Cell.water
                                (new_grid[ri][ci]).material = Cell.air
                                resolved = True

    return new_grid

async def main():
    cells = []
    for i in range(num_cells_vertical):
        cells.append([Cell(e * cell_width, i * cell_height, Cell.air) for e in range(num_cells_horizontal)])

    for cell in cells[0]:
        cell.material = Cell.wall
    for cell in cells[-1]:
        cell.material = Cell.wall
    for row in cells:
        row[0].material = Cell.wall
        row[-1].material = Cell.wall

    clock = pygame.time.Clock()
    FPS = 60

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
        mouse_buttons = pygame.mouse.get_pressed()
        if mouse_buttons[0] or mouse_buttons[2]:
            mouse_pos = pygame.mouse.get_pos()
            grid_pos = get_cell_at_mouse(mouse_pos, cell_width, cell_height, num_cells_horizontal, num_cells_vertical)
            if grid_pos:
                selected_cell = cells[grid_pos[0]][grid_pos[1]]
                if selected_cell.material != Cell.wall:
                    if mouse_buttons[0]:
                        selected_cell.material = Cell.sand
                    elif mouse_buttons[2]:
                        selected_cell.material = Cell.water

        render(cells)
        cells = physics(cells)

        clock.tick(FPS)
        await asyncio.sleep(0)
        
    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())