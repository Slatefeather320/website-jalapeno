import pygame
import random
import asyncio

background_color = (40, 44, 52)
outline_delta = 10
outline_colour = (40 + outline_delta, 44 + outline_delta, 52 + outline_delta)

class Material:
    def __init__(self, color, rigid, string):
        self.color = color 
        self.rigid = rigid
        self.string = string

class Cell:
    air = Material(background_color, False, "Air")
    sand = Material((200, 200, 100), False, "Sand")
    water = Material((10, 10, 255), False, "Water") 
    wall = Material((0, 0, 0), True, "Wall") 
    scaffolding = Material((200, 200, 200), True, "Scaffolding")
    hotbar = [air, sand, water, scaffolding]

    def __init__(self, x, y, mat, anchored):
        self.xpos = x
        self.ypos = y
        self.material = mat
        self.anchored = anchored 

pygame.init()
pygame.font.init()
ui_font = pygame.font.SysFont("Courier New", 32, bold=True)

WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600

cell_width = 15
cell_height = 15

num_cells_horizontal = WINDOW_WIDTH // cell_width
num_cells_vertical = WINDOW_HEIGHT // cell_height

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT + 50))
pygame.display.set_caption("Pixel Game")

def render(cells_grid, hotbar_index):
    outline_colour = (80, 80, 80)
    screen.fill(background_color)
    for row in cells_grid:
        for cell in row:
            cell_rect = pygame.Rect(cell.xpos, cell.ypos, cell_width, cell_height)
            pygame.draw.rect(screen, cell.material.color, cell_rect)
            pygame.draw.rect(screen, outline_colour, cell_rect, 1)

    ui_panel_rect = pygame.Rect(0, WINDOW_HEIGHT, WINDOW_WIDTH, 50)
    pygame.draw.rect(screen, (30, 32, 38), ui_panel_rect)
    pygame.draw.line(screen, (80, 80, 80), (0, WINDOW_HEIGHT), (WINDOW_WIDTH, WINDOW_HEIGHT), 1)

    text_surface = ui_font.render(f"SELECTED: {Cell.hotbar[hotbar_index].string}", True, (220, 220, 220))
    screen.blit(text_surface, (10, WINDOW_HEIGHT + 15))

    pygame.display.flip()

def get_cell_at_mouse(mouse_pos, cell_width, cell_height, num_cells_horizontal, num_cells_vertical):
    mouse_x, mouse_y = mouse_pos
    col = mouse_x // cell_width
    row = mouse_y // cell_height
    if 0 <= col < num_cells_horizontal and 0 <= row < num_cells_vertical:
        return row, col
    return None

def anchor_propegate(grid, ri, ci):
    grid[ri][ci].anchored = True
    for i in [-1, 0, 1]:
        for j in [-1, 0, 1]:
            if 0 <= ri + i < num_cells_vertical and 0 <= ci + j < num_cells_horizontal:
                cur = grid[ri + i][ci + j]
                if (cur.anchored == False) and (cur.material.rigid) and not (i == 0 and j == 0):
                    anchor_propegate(grid, ri + i, ci + j)

def physics(old_grid):
    new_grid = [[Cell(cell.xpos, cell.ypos, cell.material, False) for cell in row] for row in old_grid]
    anchor_propegate(new_grid, 0, 0)

    for ri in range(0, num_cells_vertical - 1):
        for ci in range(0, num_cells_horizontal):
            cur = old_grid[ri][ci] 

            if cur.material == Cell.scaffolding:
                if old_grid[ri + 1][ci].material == Cell.air and not new_grid[ri][ci].anchored:
                    new_grid[ri][ci].material = Cell.air
                    new_grid[ri + 1][ci].material = Cell.scaffolding
                elif old_grid[ri + 1][ci].material == Cell.water and not new_grid[ri][ci].anchored:
                    new_grid[ri][ci].material = Cell.water
                    new_grid[ri + 1][ci].material = Cell.scaffolding

            if cur.material == Cell.sand:
                if (old_grid[ri + 1][ci]).material == Cell.air: 
                    (new_grid[ri + 1][ci]).material = Cell.sand
                    (new_grid[ri][ci]).material = Cell.air
                elif (old_grid[ri + 1][ci]).material == Cell.water: 
                    (new_grid[ri][ci]).material = Cell.water
                    (new_grid[ri + 1][ci]).material = Cell.sand
                else:
                    resolved = False
                    order = [[1, -1], [-1, 1]][random.randint(0, 1)]
                    for i in range(0, 2):
                        if (old_grid[ri + 1][ci + order[i]]).material == Cell.air and not resolved:
                            (new_grid[ri + 1][ci + order[i]]).material = Cell.sand
                            (new_grid[ri][ci]).material = Cell.air
                            resolved = True
                    for i in range(0, 2):
                        if (old_grid[ri + 1][ci + order[i]]).material == Cell.water and not resolved:
                            (new_grid[ri + 1][ci + order[i]]).material = Cell.sand
                            (new_grid[ri][ci]).material = Cell.water
                            resolved = True                   
            
            if cur.material == Cell.water:
                if (old_grid[ri + 1][ci]).material == Cell.air: 
                    (new_grid[ri + 1][ci]).material = Cell.water
                    (new_grid[ri][ci]).material = Cell.air
                else:
                    resolved = False
                    order = [[1, -1], [-1, 1]][random.randint(0, 1)]
                    for i in range(0, 2):
                        if (old_grid[ri + 1][ci + order[i]]).material == Cell.air and (new_grid[ri + 1][ci]).material == Cell.air and not resolved:
                            (new_grid[ri + 1][ci + order[i]]).material = Cell.water
                            (new_grid[ri][ci]).material = Cell.air
                            resolved = True
                    if not resolved:
                        for i in range(0, 2):
                            if (old_grid[ri][ci + order[i]]).material == Cell.air and (new_grid[ri][ci + order[i]]).material == Cell.air and not resolved:
                                (new_grid[ri][ci + order[i]]).material = Cell.water
                                (new_grid[ri][ci]).material = Cell.air
                                resolved = True

    return new_grid

async def main():
    cells = []
    for i in range(num_cells_vertical):
        cells.append([Cell(e * cell_width, i * cell_height, Cell.air, False) for e in range(num_cells_horizontal)])

    for cell in cells[0]:
        cell.material = Cell.wall
    for cell in cells[-1]:
        cell.material = Cell.wall
    for row in cells:
        row[0].material = Cell.wall
        row[-1].material = Cell.wall
    cells[0][0].anchored = True

    clock = pygame.time.Clock()
    FPS = 60

    running = True
    hotbar_index = 0
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                grid_pos = get_cell_at_mouse(mouse_pos, cell_width, cell_height, num_cells_horizontal, num_cells_vertical)
                
                if grid_pos:
                    if event.button == 3:
                        hotbar_index += 1
                        if hotbar_index >= len(Cell.hotbar):
                            hotbar_index = 0

        mouse_buttons = pygame.mouse.get_pressed()
        if mouse_buttons[0]:  
            mouse_pos = pygame.mouse.get_pos()
            grid_pos = get_cell_at_mouse(mouse_pos, cell_width, cell_height, num_cells_horizontal, num_cells_vertical)  
            if grid_pos:
                selected_cell = cells[grid_pos[0]][grid_pos[1]]
                if selected_cell.material != Cell.wall:
                    selected_cell.material = Cell.hotbar[hotbar_index]

        render(cells, hotbar_index)
        cells = physics(cells)

        clock.tick(FPS)
        await asyncio.sleep(0)
        
    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())